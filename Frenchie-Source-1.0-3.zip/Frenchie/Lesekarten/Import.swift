import Foundation

enum ImportError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
enum Importer {
    static func read(_ url: URL) throws -> [[String]] {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= 25_000_000 else { throw ImportError.message("Die Datei darf höchstens 25 MB groß sein.") }
        let data = try Data(contentsOf: url)
        if url.pathExtension.lowercased() == "xlsx" { return try xlsx(data) }
        guard let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) else { throw ImportError.message("Bitte speichern Sie die CSV-Datei als UTF-8.") }
        return try csv(text)
    }
    static func csv(_ input: String) throws -> [[String]] {
        let text = input.replacingOccurrences(of: "\u{FEFF}", with: "").replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        let chars = Array(text); var quoted = false; var counts: [Character:Int] = [";":0, ",":0, "\t":0]
        for c in chars { if c == "\"" { quoted.toggle() }; if c == "\n" && !quoted { break }; if !quoted && counts[c] != nil { counts[c, default: 0] += 1 } }
        let sep = [Character(";"), ",", "\t"].max { counts[$0, default: 0] < counts[$1, default: 0] }!
        var rows: [[String]] = [], row: [String] = [], field = ""; quoted = false; var i = 0
        func finishRow() { row.append(field); field = ""; if row.contains(where: { !$0.isEmpty }) { rows.append(row) }; row = [] }
        while i < chars.count {
            let c = chars[i]
            if c == "\"" {
                if quoted && i + 1 < chars.count && chars[i+1] == "\"" { field.append("\""); i += 1 } else { quoted.toggle() }
            } else if c == sep && !quoted { row.append(field); field = "" }
            else if c == "\n" && !quoted { finishRow() }
            else { field.append(c) }
            i += 1
        }
        guard !quoted else { throw ImportError.message("Die CSV-Datei enthält ein nicht geschlossenes Anführungszeichen.") }
        if !field.isEmpty || !row.isEmpty { finishRow() }
        return rows
    }
    static func xlsx(_ data: Data) throws -> [[String]] {
        let zip = try Zip(data)
        var shared: [String] = []
        if let xml = try zip.file("xl/sharedStrings.xml") { let parser = SheetXML(); try parser.parse(xml); shared = parser.shared }
        var path = "xl/worksheets/sheet1.xml"
        if let workbook = try zip.file("xl/workbook.xml"), let relations = try zip.file("xl/_rels/workbook.xml.rels") {
            let w = SheetXML(); try w.parse(workbook)
            let r = SheetXML(); try r.parse(relations)
            if let id = w.firstSheet, let target = r.relations[id] {
                path = target.hasPrefix("/") ? String(target.dropFirst()) : "xl/" + target
                path = (path as NSString).standardizingPath
            }
        }
        guard let xml = try zip.file(path) else { throw ImportError.message("Das erste Tabellenblatt wurde nicht gefunden.") }
        let parser = SheetXML(); parser.shared = shared; try parser.parse(xml); return parser.rows
    }
}
// XLSX uses ZIP containers. Central-directory sizes also support data descriptors.
struct Zip {
    let bytes: [UInt8]
    struct Entry { let method: Int; let size: Int; let expanded: Int; let offset: Int; let crc: UInt32 }
    var entries: [String:Entry] = [:]
    init(_ data: Data) throws {
        bytes = Array(data)
        guard bytes.count >= 22 else { throw ImportError.message("Ungültige Excel-Datei.") }
        var end: Int?
        for i in stride(from: bytes.count - 22, through: max(0, bytes.count - 65557), by: -1) {
            if u32(i) == 0x06054b50 { end = i; break }
        }
        guard let end, u16(end+4) == 0, u16(end+6) == 0 else { throw ImportError.message("Dieses ZIP-Format wird nicht unterstützt.") }
        var pos = Int(u32(end+16))
        for _ in 0..<u16(end+10) {
            guard pos + 46 <= bytes.count, u32(pos) == 0x02014b50 else { throw ImportError.message("Beschädigtes Excel-Archiv.") }
            let n = u16(pos+28), extra = u16(pos+30), comment = u16(pos+32)
            guard pos + 46 + n + extra + comment <= bytes.count, u16(pos+8) & 1 == 0 else { throw ImportError.message("Beschädigte oder verschlüsselte Excel-Datei.") }
            let name = String(decoding: bytes[(pos+46)..<(pos+46+n)], as: UTF8.self)
            entries[name] = Entry(method: u16(pos+10), size: Int(u32(pos+20)), expanded: Int(u32(pos+24)), offset: Int(u32(pos+42)), crc: u32(pos+16))
            pos += 46 + n + extra + comment
        }
    }
    func u16(_ i: Int) -> Int { guard i >= 0, i + 2 <= bytes.count else { return 0 }; return Int(bytes[i]) | Int(bytes[i+1]) << 8 }
    func u32(_ i: Int) -> UInt32 { UInt32(u16(i)) | UInt32(u16(i+2)) << 16 }
    func file(_ name: String) throws -> Data? {
        guard let e = entries[name] else { return nil }
        guard e.offset + 30 <= bytes.count, u32(e.offset) == 0x04034b50, e.expanded <= 40_000_000 else { throw ImportError.message("Ungültiger oder zu großer Excel-Inhalt.") }
        let start = e.offset + 30 + u16(e.offset+26) + u16(e.offset+28)
        guard start <= bytes.count, e.size <= bytes.count-start else { throw ImportError.message("Unvollständige Excel-Datei.") }
        var source = Array(bytes[start..<(start+e.size)]); var output: [UInt8]
        if e.method == 0 { output = source }
        else if e.method == 8 {
            output = [UInt8](repeating: 0, count: max(1,e.expanded)); var stream = z_stream()
            guard inflateInit2_(&stream, -MAX_WBITS, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size)) == Z_OK else { throw ImportError.message("Excel-Dekomprimierung fehlgeschlagen.") }
            defer { inflateEnd(&stream) }
            let status = source.withUnsafeMutableBytes { src in output.withUnsafeMutableBytes { dst in
                stream.next_in = src.bindMemory(to: UInt8.self).baseAddress; stream.avail_in = uInt(e.size)
                stream.next_out = dst.bindMemory(to: UInt8.self).baseAddress; stream.avail_out = uInt(dst.count)
                return inflate(&stream, Z_FINISH)
            } }
            guard status == Z_STREAM_END, stream.total_out == e.expanded else { throw ImportError.message("Beschädigte komprimierte Excel-Daten.") }
            output = Array(output.prefix(e.expanded))
        } else { throw ImportError.message("Diese Excel-Komprimierung wird nicht unterstützt.") }
        let checksum = output.withUnsafeBytes { crc32(0, $0.bindMemory(to: UInt8.self).baseAddress, uInt($0.count)) }
        guard output.count == e.expanded, UInt32(checksum) == e.crc else { throw ImportError.message("Die Excel-Prüfsumme stimmt nicht.") }
        return Data(output)
    }
}
final class SheetXML: NSObject, XMLParserDelegate {
    var shared: [String] = []; var rows: [[String]] = []; var firstSheet: String?; var relations: [String:String] = [:]
    private var row: [String] = []; private var column = 0; private var type = ""; private var value = ""; private var text = ""; private var capture = false; private var inSI = false
    func parse(_ data: Data) throws {
        let parser = XMLParser(data: data); parser.shouldProcessNamespaces = true; parser.shouldResolveExternalEntities = false; parser.delegate = self
        guard parser.parse() else { throw ImportError.message("Excel-XML konnte nicht gelesen werden: \(parser.parserError?.localizedDescription ?? "Ungültige Datei")") }
    }
    func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes a: [String:String]) {
        if name == "sheet", firstSheet == nil { firstSheet = a["r:id"] }
        if name == "Relationship", let id = a["Id"], let target = a["Target"], a["TargetMode"] != "External" { relations[id] = target }
        if name == "si" { inSI = true; text = "" }
        if name == "row" { row = [] }
        if name == "c" {
            column = 0
            for c in (a["r"] ?? "").uppercased().utf8 { if c >= 65 && c <= 90 { column = column * 26 + Int(c - 64) } else { break } }
            column = column == 0 ? row.count : column - 1
            if column > 16383 { parser.abortParsing(); return }
            type = a["t"] ?? ""; value = ""; text = ""
        }
        if name == "v" || name == "t" { capture = true }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { if capture { if inSI || type == "inlineStr" { text += string } else { value += string } } }
    func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
        if name == "v" || name == "t" { capture = false }
        if name == "si" { shared.append(text); inSI = false }
        if name == "c" {
            var result = type == "inlineStr" ? text : value
            if type == "s" { guard let i = Int(value), shared.indices.contains(i) else { parser.abortParsing(); return }; result = shared[i] }
            while row.count <= column { row.append("") }; row[column] = result
        }
        if name == "row", !row.isEmpty { rows.append(row) }
    }
}
