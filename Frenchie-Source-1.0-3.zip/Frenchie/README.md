# Frenchie – le chien qui lit

Kostenlose Französisch-Karteikarten für iPhone und iPad ab iOS/iPadOS 17. Die App enthält keine Bücher oder Beispieltexte. Deutsche Übersetzungen, französische Sätze und optionale Lautschrift werden aus eigenen XLSX- oder CSV-Dateien importiert.

## Funktionen

Bibliothek mit alphabetischer Sortierung, Karten mit zwei Sprachseiten, französische Sprachausgabe, Navigation zurück/weiter/zu Zeile, Wiederaufnahme der zuletzt gezeigten Karte und wählbare Lernrichtung. Bücher lassen sich mit Rückfrage löschen. Es gibt keine Werbung, Registrierung oder Lernstatistik.

## Installation über AltStore Classic

1. Installiere [AltServer und AltStore Classic](https://faq.altstore.io/altstore-classic/how-to-install-altstore-macos) nach der offiziellen Anleitung.
2. Lade `Frenchie-1.0-3.ipa` aus den [GitHub Releases](https://github.com/jgruhl-sw/SprachenLernen/releases/tag/frenchie-1.0-3) auf dein iPhone oder iPad.
3. Öffne AltStore Classic, wähle unter „My Apps“ das Plus und anschließend die IPA-Datei. AltStore signiert sie mit deinem eigenen Apple-Account.
4. Halte AltServer für Installation und spätere Erneuerungen erreichbar. Beachte die in AltStore angezeigte Gültigkeit; bei kostenlosen Apple-Accounts ist regelmäßiges Erneuern erforderlich.

Alternativ kann diese Quelle in AltStore Classic hinzugefügt werden:

https://github.com/jgruhl-sw/SprachenLernen/releases/download/frenchie-1.0-3/altstore.json

Die IPA ist unsigniert für die Signierung durch AltStore. Sie ist für AltStore Classic vorgesehen. Der AltStore-Installationsweg auf einem echten Gerät wurde nicht geprüft. Die App-Funktionen und der Bruno-Import waren zuvor auf einem iPad geprüft worden; das bestätigt nicht die AltStore-Installation.

## Import

Das erste XLSX-Tabellenblatt bzw. die CSV-Datei benötigt die Spalten `Zeilennummer`, `deutsch`, `französisch`, `Lautschrift`, `Buch`. Die leere Vorlage ist beigelegt. Pro Buch bezeichnet Zeile 0 den Titel; Textzeilen beginnen bei 1. Numerische Kennziffern sind nichtnegative ganze Zahlen. Die Lautschrift darf leer bleiben. Maximale Dateigröße: 25 MB.

Bei identischer Buch- und Zeilennummer wird ein Eintrag nur bei identischem französischem Text aktualisiert. Andernfalls wird der Konflikt gemeldet und der vorhandene Eintrag bleibt erhalten. Die App erzeugt keine Übersetzungen oder Lautschrift.

## Aus dem Quellcode bauen

Öffne `Lesekarten.xcodeproj` mit Xcode. Für eine direkte Geräteinstallation wähle dein eigenes Entwicklerteam. Für eine unsignierte IPA führe auf einem Mac mit Xcode und Python 3 aus:

```sh
bash build-ipa.sh
```

Das Ergebnis liegt in `dist/`. Keine Zugangsdaten, Zertifikate oder Provisioning-Profile werden benötigt. Der Release-Build wurde mit Xcode 27 erfolgreich erstellt und auf eine leere Bibliothek geprüft. Dieses Archiv enthält den zu Version 1.0 (Build 3) gehörenden Quellcode.

[Support](https://www.gruhl.de/app/frenchie/support.html) · [Datenschutz](https://www.gruhl.de/app/frenchie/datenschutz.html)

Lizenz: GPL-3.0 gemäß der LICENSE-Datei dieses Repositorys.
