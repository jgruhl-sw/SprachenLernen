import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

@main struct LesekartenApp: App {
    @StateObject private var store = LibraryStore()
    var body: some Scene { WindowGroup { Reader().environmentObject(store) } }
}
@MainActor final class Speaker: ObservableObject {
    private let synth = AVSpeechSynthesizer()
    func stop() { synth.stopSpeaking(at: .immediate) }
    func speak(_ text: String) {
        stop()
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)
        let u = AVSpeechUtterance(string: text)
        u.voice = AVSpeechSynthesisVoice(language: "fr-FR"); u.rate = 0.43
        synth.speak(u)
    }
}
@MainActor final class ViewState: ObservableObject {
    @Published var library = false
    @Published var jump = false
    @Published var line = ""
    @Published var importing = false
    @Published var deleting: Entry?
    @Published var help = false
}
struct Reader: View {
    @StateObject private var ui = ViewState()
    @EnvironmentObject var store: LibraryStore
    @StateObject private var speaker = Speaker()
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                if let card = store.current {
                    Text(store.books.first(where: { $0.book == card.book })?.de ?? "").font(.headline).multilineTextAlignment(.center)
                    Picker("Lernrichtung", selection: Binding(get: { store.state.frenchFirst }, set: { store.direction($0) })) {
                        Text("Deutsch → Französisch").tag(false)
                        Text("Französisch → Deutsch").tag(true)
                    }.pickerStyle(.menu)
                    ScrollView {
                        VStack(alignment: .leading, spacing: 24) {
                            Text("\(card.line)").font(.caption2).foregroundStyle(.secondary)
                            Text(store.state.showingFrench ? "FRANÇAIS" : "DEUTSCH").font(.caption).tracking(2).foregroundStyle(.secondary)
                            Text(store.state.showingFrench ? card.fr : card.de).font(.system(.title2, design: .serif)).frame(maxWidth: .infinity, alignment: .leading)
                            if store.state.showingFrench { Text(card.ipa.isEmpty ? "Keine Lautschrift vorhanden" : card.ipa).font(.title3).foregroundStyle(.secondary) }
                            Text("Tippen zum Umdrehen").font(.footnote).foregroundStyle(.secondary)
                        }.padding(28).frame(maxWidth: .infinity, minHeight: 320, alignment: .topLeading)
                    }
                    .background(store.state.showingFrench ? Color.blue.opacity(0.08) : Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 24))
                    .contentShape(Rectangle()).onTapGesture { store.flip() }
                    .accessibilityAction(named: "Karte umdrehen") { store.flip() }
                    Button { speaker.speak(card.fr) } label: { Label("Französisch anhören", systemImage: "speaker.wave.2.fill") }.buttonStyle(.borderedProminent)
                    HStack {
                        Button { store.move(-1) } label: { Label("Zurück", systemImage: "chevron.left") }.disabled(store.position == 0)
                        Spacer()
                        Button("Zu Zeile") { ui.line = ""; ui.jump = true }
                        Spacer()
                        Button { store.move(1) } label: { Label("Weiter", systemImage: "chevron.right") }.disabled(store.position >= store.sentences.count - 1)
                    }.buttonStyle(.bordered)
                } else {
                    ContentUnavailableView("Text auswählen", systemImage: "books.vertical", description: Text("Öffne die Bibliothek und importiere eine Excel-Tabelle oder wähle einen Text."))
                    Button("Bibliothek") { ui.library = true }.buttonStyle(.borderedProminent)
                }
            }.padding().navigationTitle("Frenchie - le chien qui lit").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarLeading) { Button { ui.library = true } label: { Label("Bibliothek", systemImage: "books.vertical") } } }
        }
        .sheet(isPresented: $ui.library) { LibraryView() }
        .alert("Zu Zeile", isPresented: $ui.jump) {
            TextField("Zeilennummer", text: $ui.line).keyboardType(.numberPad)
            Button("Gehe zu") { store.jump(ui.line) }; Button("Abbrechen", role: .cancel) {}
        } message: { Text("Zeilennummer innerhalb des geöffneten Textes") }
        .alert("Hinweis", isPresented: Binding(get: { store.message != nil && !ui.library }, set: { if !$0 { store.message = nil } })) { Button("OK") { store.message = nil } } message: { Text(store.message ?? "") }
        .onChange(of: store.state.selected) { speaker.stop() }
        .onChange(of: ui.library) { if ui.library { speaker.stop() } }
    }
}
struct LibraryView: View {
    @StateObject private var ui = ViewState()
    @EnvironmentObject var store: LibraryStore
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.books) { book in
                    Button { store.open(book.book); if store.current?.book == book.book { dismiss() } } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(book.de).foregroundStyle(.primary)
                            Text("Buch \(book.book) · \(store.state.entries.filter { $0.book == book.book && $0.line > 0 }.count) Zeilen").font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 6)
                    }.swipeActions { Button("Löschen", role: .destructive) { ui.deleting = book } }
                    .contextMenu { Button("Löschen", role: .destructive) { ui.deleting = book } }
                }
            }.overlay { if store.books.isEmpty { ContentUnavailableView("Bibliothek leer", systemImage: "books.vertical", description: Text("Importiere eine .xlsx-Datei mit einer Titelzeile 0 je Buch.")) } }
            .navigationTitle("Bibliothek")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Schließen") { dismiss() } }
                ToolbarItem(placement: .bottomBar) { Button("Importhilfe & Datenschutz") { ui.help = true } }
                ToolbarItem(placement: .topBarTrailing) { Button { ui.importing = true } label: { Label("Excel / CSV importieren", systemImage: "square.and.arrow.down") } }
            }
            .fileImporter(isPresented: $ui.importing, allowedContentTypes: [UTType(filenameExtension: "xlsx") ?? .data, .commaSeparatedText]) { result in
                do { try store.importRows(Importer.read(result.get())) } catch { store.message = error.localizedDescription }
            }
            .sheet(isPresented: $ui.help) {
                NavigationStack {
                    List {
                        Section("Eigene Texte importieren") {
                            Text("Frenchie startet mit einer leeren Bibliothek. Erstelle eine Excel-Datei (.xlsx) oder CSV-Datei mit den Spalten Zeilennummer, deutsch, französisch, Lautschrift und Buch. Bei Excel wird das erste Tabellenblatt gelesen.")
                            Text("Buch ist eine numerische Kennziffer. Zeile 0 enthält den Titel in beiden Sprachen. Die Textzeilen beginnen bei 1. Die Lautschrift ist optional und wird aus deiner Datei übernommen.")
                            Text("Wähle in der Bibliothek die Import-Schaltfläche. Bestehende Zeilen werden nur bei übereinstimmendem Buch, Zeilennummer und französischem Text aktualisiert. Verwende nur Texte, die du verwenden darfst.")
                        }
                        Section("Datenschutz") {
                            Text("Frenchie speichert importierte Texte, die letzte Karte und die Lernrichtung lokal auf deinem Gerät. Die App betreibt keinen Server, verwendet keine Werbung und enthält keine Analyse- oder Trackingdienste. Der Entwickler erhält keine importierten Texte oder Nutzungsdaten.")
                            Text("Die Audioausgabe erfolgt über die Sprachausgabe von iOS. Die Dateiauswahl und gegebenenfalls Cloud-Dateien werden vom Betriebssystem beziehungsweise deinem Dateianbieter verwaltet. Gerätesicherungen richten sich nach deinen Systemeinstellungen.")
                            Text("Bücher kannst du in der Bibliothek löschen. Beim Entfernen der App werden ihre lokalen Daten gelöscht; externe Originaldateien und vorhandene Sicherungen bleiben davon unberührt.")
                        }
                    }.navigationTitle("Hilfe & Datenschutz")
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Fertig") { ui.help = false } } }
                }
            }
            .alert("wirklich löschen?", isPresented: Binding(get: { ui.deleting != nil }, set: { if !$0 { ui.deleting = nil } })) {
                Button("Löschen", role: .destructive) { if let book = ui.deleting { store.delete(book.book) }; ui.deleting = nil }
                Button("Abbrechen", role: .cancel) { ui.deleting = nil }
            } message: { Text("Alle Einträge von „\(ui.deleting?.de ?? "")“ werden gelöscht.") }
            .alert("Import / Hinweis", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) { Button("OK") { store.message = nil } } message: { Text(store.message ?? "") }
        }
    }
}
