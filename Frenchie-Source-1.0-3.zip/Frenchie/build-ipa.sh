#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
xcodebuild -project Lesekarten.xcodeproj -scheme Lesekarten -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
mkdir -p dist
python3 - <<'PY'
from pathlib import Path
import zipfile,json,plistlib
app=Path('build/Build/Products/Release-iphoneos/Lesekarten.app')
assert json.loads((app/'Basis.json').read_text()) == [], 'Release muss ohne Bücher bleiben'
i=plistlib.loads((app/'Info.plist').read_bytes())
out=Path('dist')/f"Frenchie-{i['CFBundleShortVersionString']}-{i['CFBundleVersion']}.ipa"
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(app.rglob('*')):
  if p.is_file(): z.write(p,Path('Payload/Lesekarten.app')/p.relative_to(app))
print(out.resolve())
PY
