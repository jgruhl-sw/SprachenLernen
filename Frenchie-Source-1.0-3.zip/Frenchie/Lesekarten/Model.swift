import Foundation
import Combine

struct Entry: Codable, Identifiable, Equatable {
    var line: Int
    var book: Int
    var de: String
    var fr: String
    var ipa: String
    var id: String { "\(book):\(line)" }
}
struct LibraryState: Codable {
    var entries: [Entry] = []
    var selected: String?
    var frenchFirst = false
    var showingFrench = false
}
@MainActor final class LibraryStore: ObservableObject {
    @Published private(set) var state = LibraryState()
    @Published var message: String?
    private let url: URL
    private var writable = true
    init(url: URL? = nil, seed: Bool = true) {
        self.url = url ?? URL.applicationSupportDirectory.appendingPathComponent("Lesekarten/library.json")
        do {
            if FileManager.default.fileExists(atPath: self.url.path) {
                state = try JSONDecoder().decode(LibraryState.self, from: Data(contentsOf: self.url))
            } else if seed, let source = Bundle.main.url(forResource: "Basis", withExtension: "json") {
                state.entries = try JSONDecoder().decode([Entry].self, from: Data(contentsOf: source))
                state.selected = state.entries.first(where: { $0.line > 0 })?.id
                try write(state)
            }
        } catch { writable = false; message = "Die Daten konnten nicht geladen werden: \(error.localizedDescription)" }
    }
    private func write(_ value: LibraryState) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(value).write(to: url, options: .atomic)
    }
    private func commit(_ value: LibraryState) {
        guard writable else { message = "Speichern ist wegen eines Ladefehlers gesperrt."; return }
        do { try write(value); state = value } catch { message = "Speichern fehlgeschlagen: \(error.localizedDescription)" }
    }
    var books: [Entry] { state.entries.filter { $0.line == 0 }.sorted { $0.de.localizedStandardCompare($1.de) == .orderedAscending } }
    var current: Entry? { state.entries.first { $0.id == state.selected && $0.line > 0 } }
    var sentences: [Entry] {
        guard let book = current?.book else { return [] }
        return state.entries.filter { $0.book == book && $0.line > 0 }.sorted { $0.line < $1.line }
    }
    var position: Int { sentences.firstIndex { $0.id == state.selected } ?? 0 }
    func select(_ entry: Entry) { var s = state; s.selected = entry.id; s.showingFrench = s.frenchFirst; commit(s) }
    func open(_ book: Int) {
        guard let first = state.entries.filter({ $0.book == book && $0.line > 0 }).min(by: { $0.line < $1.line }) else { message = "Dieser Text enthält noch keine Sätze."; return }
        if current?.book != book { select(first) }
    }
    func flip() { var s = state; s.showingFrench.toggle(); commit(s) }
    func direction(_ french: Bool) { var s = state; s.frenchFirst = french; s.showingFrench = french; commit(s) }
    func move(_ offset: Int) { let list = sentences; let i = position + offset; if list.indices.contains(i) { select(list[i]) } }
    func jump(_ text: String) {
        guard let n = Int(text), let entry = sentences.first(where: { $0.line == n }) else { message = "Diese Zeilennummer gibt es in diesem Text nicht."; return }
        select(entry)
    }
    func delete(_ book: Int) {
        var s = state; s.entries.removeAll { $0.book == book }
        if current?.book == book { s.selected = nil }
        commit(s)
    }
    func importRows(_ rows: [[String]]) throws {
        guard let header = rows.first else { throw ImportError.message("Die Tabelle ist leer.") }
        let h = header.map { $0.lowercased().trimmingCharacters(in: .whitespacesAndNewlines) }
        let names = ["zeilennummer", "deutsch", "französisch", "lautschrift", "buch"]
        let indices = try names.map { name -> Int in
            guard let i = h.firstIndex(of: name) else { throw ImportError.message("Spalte fehlt: \(name)") }; return i
        }
        var incoming: [Entry] = []; var seen = Set<String>()
        for (index, row) in rows.dropFirst().enumerated() {
            if row.allSatisfy({ $0.isEmpty }) { continue }
            func get(_ i: Int) -> String { row.indices.contains(indices[i]) ? row[indices[i]] : "" }
            guard let line = Int(get(0)), let book = Int(get(4)), line >= 0, book >= 0, !get(1).isEmpty, !get(2).isEmpty else { throw ImportError.message("Ungültiger Eintrag in Excel-Zeile \(index + 2). Nummern müssen ganze, nichtnegative Zahlen sein; beide Texte sind erforderlich.") }
            let e = Entry(line: line, book: book, de: get(1), fr: get(2), ipa: get(3))
            guard seen.insert(e.id).inserted else { throw ImportError.message("Doppelte Kombination aus Buch und Zeilennummer in Excel-Zeile \(index + 2).") }
            incoming.append(e)
        }
        var s = state; var added = 0; var updated = 0; var conflicts: [String] = []
        for e in incoming {
            if let i = s.entries.firstIndex(where: { $0.id == e.id }) {
                if s.entries[i].fr == e.fr { s.entries[i] = e; updated += 1 }
                else { conflicts.append("Buch \(e.book), Zeile \(e.line)") }
            } else { s.entries.append(e); added += 1 }
        }
        let titles = Set(s.entries.filter { $0.line == 0 }.map(\.book))
        guard s.entries.allSatisfy({ titles.contains($0.book) }) else { throw ImportError.message("Für jedes Buch ist eine Titelzeile mit Zeilennummer 0 erforderlich. Der Import wurde verworfen.") }
        // Open the first successfully imported book, including when another book was open.
        if let book = incoming.first(where: { e in s.entries.contains { $0.id == e.id && $0.fr == e.fr } })?.book, current?.book != book,
           let first = s.entries.filter({ $0.book == book && $0.line > 0 }).min(by: { $0.line < $1.line }) {
            s.selected = first.id; s.showingFrench = s.frenchFirst
        }
        guard writable else { throw ImportError.message("Speichern ist wegen eines Ladefehlers gesperrt.") }
        try write(s); state = s
        message = "\(added) neue Zeilen, \(updated) aktualisierte Zeilen.\n\(conflicts.count) Konflikte unverändert belassen." + (conflicts.isEmpty ? "" : "\n" + conflicts.prefix(20).joined(separator: "\n"))
    }
}
